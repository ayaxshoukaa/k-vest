---
name: Obsidian Sovereign
colors:
  surface: '#111318'
  surface-dim: '#111318'
  surface-bright: '#37393e'
  surface-container-lowest: '#0c0e13'
  surface-container-low: '#191c20'
  surface-container: '#1d2024'
  surface-container-high: '#272a2f'
  surface-container-highest: '#32353a'
  on-surface: '#e1e2e9'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#e1e2e9'
  inverse-on-surface: '#2e3035'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#45dfa4'
  on-tertiary: '#003825'
  tertiary-container: '#00b982'
  on-tertiary-container: '#00422c'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#68fcbf'
  tertiary-fixed-dim: '#45dfa4'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#111318'
  on-background: '#e1e2e9'
  surface-variant: '#32353a'
typography:
  display-hero:
    fontFamily: Syne
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Syne
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Syne
    fontSize: 38px
    fontWeight: '600'
    lineHeight: 46px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Syne
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Syne
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Syne
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: 0em
  body-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  telemetry-value:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.02em
  telemetry-unit:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.14em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 2.5rem
  margin-mobile: 1.25rem
  margin-desktop: 3.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 2.75rem
---

## Brand & Style

This design system embodies bespoke luxury at the intersection of private wealth management, family office infrastructure, and sovereign algorithmic intelligence. The interface is engineered for ultra-high-net-worth individuals, institutional stewards, and vanguard allocators who operate at the frontiers of global finance.

The visual thesis merges **futuristic glassmorphic high-precision UI** with **haute horlogerie dark aesthetic principles**. The spatial architecture relies on deep void layers (obsidian blacks and midnight voids) punctuated by directional specular light leaks, micro-luminescent borders, and restrained neon energy radiates (emerald and cyan).

Key brand attributes:
- **Sovereign Discretion:** Interfaces prioritize low cognitive noise, dense yet perfectly rhythmic information architecture, and privacy shielding.
- **Architectural Precision:** Structural alignments evoke high-end instrumentation, telemetry cockpit displays, and bespoke chronometer dials rather than generic SaaS dashboards.
- **Radiant Depth:** Translucent obsidian panels with microscopic metallic edge-treatments hover above cosmic field gradients, establishing unmistakable luxury and untouchable pedigree.

## Colors

The system uses a strictly controlled chromatic hierarchy where deep obsidian darkness provides the baseline, and surgical emerald-cyan telemetry accents represent liquidity, performance, and institutional authority.

### Color Tiers & Spatial Usage
- **Base Void (`#05070B`):** The master ambient backdrop. Represents absolute ground level.
- **Midnight Tiers (`#090D16`, `#0D1322`, `#141D33`):** Stepped surface containers. Applied to elevated cards, modular telemetry panels, and docked drawers.
- **Primary Kinetic Accent (`#10B981`):** High-yield telemetry indicators, primary confirmations, and alpha metrics. Must be balanced with soft emerald radial blurs (`rgba(16, 185, 129, 0.12)`).
- **Secondary Atmospheric Accent (`#06B6D4`):** Secondary data tracks, telemetry arcs, real-time custody feeds, and computational states.
- **Tertiary Accent (`#34D399`):** Micro-highlights, live trade pings, and positive yield deltas.
- **Platinum & Silver Scales:**
  - Header & Critical Value: Platinum White (`#F8FAFC`)
  - Primary Body & Metadata: Sterling Silver (`#E2E8F0`)
  - Subordinate Telemetry & Structural Captions: Gunmetal Slate (`#94A3B8`)
  - Demarcations & Grid Lines: Obsidian Ash (`rgba(255, 255, 255, 0.08)`)
- **Specular Hairline Accents:** Linear gradients transitioning from `rgba(16, 185, 129, 0.35)` to `rgba(255, 255, 255, 0.08)` to `rgba(6, 182, 212, 0.1)`.

## Typography

The typographical structure forms a deliberate tri-axis pairing:
1. **Syne (Display & Headlines):** Delivers sculptural luxury, distinctive structural apexes, and avant-garde confidence. Reserved for tier-1 account summaries, high-level portfolio allocations, and institutional modal headers.
2. **Plus Jakarta Sans (Body & Context):** Delivers hyper-legible, modern geometric clarity with refined kerning and warm neutral contours. Prevents eye fatigue during deep portfolio inspection.
3. **Space Grotesk (Telemetry, Figures & Data Badges):** Imparts aerospace and quantum computing rigor to currency yields, delta vectors, hash addresses, and system statuses.

All uppercase tracking in labels must maintain `letterSpacing: 0.12em` to `0.15em` to mirror physical luxury chronometer engravings. Telemetry values must utilize tabular numbers (`font-variant-numeric: tabular-nums`) to prevent shifting layouts during live algorithmic price feeds.

## Layout & Spacing

The system runs on an institutional 12-column dynamic fluid grid architecture anchored by a max width of 1680px for high-density command stations.

### Grid Anatomy
- **Desktop (1440px and above):** 12 columns, 2rem gutters, 3.5rem outer canvas margin. Telemetry decks may split into 4-column metric modules, 8-column main order-book/interactive canvas units.
- **Tablet (768px – 1439px):** 8 columns, 1.5rem gutters, 2rem canvas margin. Multi-column analytics fold into two 4-column stacked structural tracks.
- **Mobile (Below 768px):** 4 columns, 1rem gutters, 1.25rem canvas margin. All charts and orbital metrics transition to single-column swipeable glass carousels or stacked horizontal cards.

### Layout Philosophy
Negative space is treated as an active luxury material. Components must not touch or crowd; ample padding around telemetry clusters focuses user attention on mission-critical financial vectors. Nested modules obey mathematical ratios: internal card gaps are governed strictly by `space-sm` and `space-md`, while major structural sectors respect `space-xl`.

## Elevation & Depth

Visual hierarchy is maintained through optical depth, physical layering, and chromatic luminescence rather than heavy drop shadows.

### Glassmorphism & Surface Tiers
- **Tier 0 (Foundation Canvas):** `#05070B` matte base with ambient, slow-moving radial background auras (`radial-gradient(circle at 80% 10%, rgba(16, 185, 129, 0.07) 0%, transparent 60%)`).
- **Tier 1 (Static Deck Panels):** `#090D16` tinted at 75% opacity with `backdrop-filter: blur(24px)`. Trimmed with a 1px border gradient: `linear-gradient(135deg, rgba(255, 255, 255, 0.08) 0%, rgba(255, 255, 255, 0.01) 100%)`.
- **Tier 2 (Interactive Modules & Hovered Assets):** `#0D1322` at 85% opacity with `backdrop-filter: blur(32px)`. Outlined with a luminous emerald border: `linear-gradient(135deg, rgba(16, 185, 129, 0.35) 0%, rgba(6, 182, 212, 0.15) 50%, rgba(255, 255, 255, 0.03) 100%)`.
- **Tier 3 (Floating Overlays, Drawers & Modals):** `#141D33` at 92% opacity with `backdrop-filter: blur(48px)`. Supported by an ethereal outer aura: `0 24px 64px -12px rgba(0, 0, 0, 0.75), 0 0 32px 0 rgba(16, 185, 129, 0.12)`.

### Lighting & Specular Highlights
Borders are never solid flat colors; they simulate light refraction across polished metallic sapphire crystal. Top and left edges receive subtle platinum reflections, while bottom edges fade into the dark ambient void.

## Shapes

The shape system employs calibrated geometry: precise curves paired with crisp internal micro-corners. A base corner radius of `0.5rem` (`roundedness: 2`) establishes balance—retaining algorithmic sharpness without appearing utilitarian or harsh.

- **Primary Cards & Telemetry Blocks:** `1rem` (`rounded-lg`) creates an aerodynamic, high-grade casing for visual density.
- **Modals, Floating Vault Sheets & Command Centers:** `1.5rem` (`rounded-xl`) softens large glass panes against background visuals.
- **Badges, Filter Pills & Status Indicators:** Fully rounded (`rounded-full` / `9999px`) to emphasize fluidity and telemetry precision.
- **Form Controls & Action Triggers:** Standardized at `0.5rem` (`rounded-md`) to ensure crisp touch targets and clear click surfaces.

## Components

### Buttons
- **Primary Sovereign Action:** High-saturation emerald-to-cyan gradient background (`linear-gradient(135deg, #10B981 0%, #059669 100%)`) overlaid with dark obsidian typography (`#05070B`, weight 600). Enclosed by a luminous outer halo (`box-shadow: 0 0 20px rgba(16, 185, 129, 0.35)`). On hover: glow expands and brightness lifts by 5%.
- **Secondary Ghost Action:** Frosted glass surface (`rgba(255, 255, 255, 0.04)`) with a 1px boundary (`rgba(255, 255, 255, 0.12)`), platinum text (`#F8FAFC`). On hover: border activates to `rgba(16, 185, 129, 0.4)` with an ambient emerald background flush (`rgba(16, 185, 129, 0.08)`).
- **Destructive / High-Stakes Trigger:** Midnight charcoal surface edged with ruby specular warning (`rgba(244, 63, 94, 0.4)`), muted red text, glowing subtly on active intent.

### Telemetry Cards & Metric Panels
- Constructed from Tier 1 glass with specular perimeter lines.
- Top section holds uppercase telemetry labels (`label-caps`) alongside contextual micro-sparklines (emerald line with glowing SVG drop-shadow).
- Metric values are rendered in `Space Grotesk` (`telemetry-value`), accompanied by floating fractional delta pills (`+14.82%` in `#34D399` over `rgba(16, 185, 129, 0.1)`).

### Input Fields & Selectors
- Background: `#090D16` at 90% opacity with a recessed inset shadow (`inset 0 2px 4px rgba(0, 0, 0, 0.5)`).
- Border: `1px solid rgba(255, 255, 255, 0.08)`.
- Text: Platinum `#F8FAFC` in `Plus Jakarta Sans`.
- Focus State: Border transitions seamlessly to `#10B981` paired with a focused peripheral ray (`box-shadow: 0 0 0 1px #10B981, 0 0 16px rgba(16, 185, 129, 0.2)`).

### Badges & Telemetry Chips
- **Demo / Sandbox Indicator:** Frosted obsidian pill with an amber-gold hairline ring (`rgba(245, 158, 11, 0.3)`) and micro-pulsing amber beacon.
- **Institutional Tier Badge:** Polished platinum-chrome gradient fill with metallic dark text, conveying exclusive member tiers (e.g., "SYNDICATE V", "SOVEREIGN ALLOCATOR").
- **Asset Health / Status:** Miniature pill containing a live orbital dot: a center point encircled by a faint concentric ring (`rgba(16, 185, 129, 0.4)`).

### Checkboxes & Toggle Controls
- Custom squared-circle track (`0.375rem` radius). Unchecked state consists of empty obsidian glass ringed with `rgba(255, 255, 255, 0.15)`. Checked state fills with `#10B981`, featuring an obsidian micro-check mark and soft radial aura.
- Toggles implement a flush inset track with an illuminated platinum thumb emitting a cyan-emerald trail when engaged.

### Bespoke Domain Components
- **Orbital Allocation Ring:** Multi-layered concentric SVG ring visualizing sovereign asset spreads across liquid reserves, algorithmic delta, and private credit. Radiates subtle orbital dust via SVG glow filters.
- **Micro-Sparkline Matrix:** Condensed financial charting modules stripped of redundant axes, employing glowing gradients beneath the performance vectors to signify alpha trajectory.
- **Sovereign Privacy Shield:** A single-click global interaction component that instantaneously blurs all numerical portfolio holdings with dynamic glass distortion filters (`backdrop-filter: blur(12px)`), displaying sanitized percentages in their place.